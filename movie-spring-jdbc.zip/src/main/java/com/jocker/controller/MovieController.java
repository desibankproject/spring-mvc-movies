package com.jocker.controller;

import java.util.Scanner;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;

import com.movie.model.Movie;
import com.movie.service.IMovieService;

//@Controller is mandatory here
@Controller
public class MovieController {

	
	@PostMapping("addMovie")
	public String registeStudent(HttpServletRequest req,Model model){
		
		//Taking data from jsp
		String title=req.getParameter("title");
		String year=req.getParameter("year");
		String director=req.getParameter("director");
		String language=req.getParameter("language");
		String story=req.getParameter("story");
		String poster=req.getParameter("poster");
		 Movie movie=new Movie(title,year,director,language,story,poster);
		  
		 ApplicationContext context=new ClassPathXmlApplicationContext("movie-service-dao.xml");
		  IMovieService movieService=(IMovieService)context.getBean("MovieService");
		  
		  String hold= movieService.save(movie);
		//model is used to carry data from controller to jsp
		//it is similar to req.setAttribute("student", student);
		  return "msuccess"; //no need to write extension
	}

}
